import requests

API_KEY = "rTjS9rZcvBMCeurVY8FR"

url = "https://api.electricitymaps.com/v4/carbon-intensity/latest?zone=DE"
r = requests.get(url, headers={"auth-token": API_KEY})
data = r.json()

print("Carbon value  :", data["carbonIntensity"])
print("Last updated  :", data["datetime"])
print("Data source   :", data.get("estimationMethod", "measured"))