from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import json
import random
import math
from datetime import datetime

# Import your scorer functions
from scorer import get_all_scores, log_and_calculate_savings, REGIONS

app = FastAPI(title="Eco-Routing Load Balancer")

# ════════════════════════════════════════════════════════════
#  API ENDPOINTS
# ════════════════════════════════════════════════════════════

@app.get("/health")
def health():
    return {"status": "running", "timestamp": datetime.now().isoformat()}

@app.get("/best-region")
def best_region():
    scores = get_all_scores()
    best   = scores[0]
    co2_saved, avg_carbon = log_and_calculate_savings(best, scores)
    return {
        "route_to":     best["name"],
        "location":     best["location"],
        "aws_region":   best["aws"],
        "score":        best["score"],
        "carbon":       best["carbon"],
        "pue":          best["pue"],
        "latency_ms":   best["latency"],
        "renewable_pct":best["renewable"],
        "co2_saved_g":  co2_saved,
        "timestamp":    datetime.now().isoformat()
    }

@app.get("/scores")
def all_scores():
    return {
        "timestamp":  datetime.now().isoformat(),
        "pue_source": "AWS + GCP Sustainability Reports 2024",
        "formula":    "Score = Carbon(35%) + Cooling(30%) + Latency(20%) + Renewable(15%)",
        "regions":    get_all_scores()
    }

@app.post("/submit-job")
def submit_job(job_type: str = "batch", max_latency_ms: int = 300):
    """
    SLA-Aware Eco-Router:
    - realtime jobs → best region that meets latency SLA
    - batch jobs    → defer if carbon > threshold, else route to greenest
    """
    scores          = get_all_scores()
    CARBON_THRESHOLD= 100  # gCO2/kWh

    if job_type == "realtime":
        # SLA-aware: pick greenest region within latency limit
        eligible = [r for r in scores if r["latency"] <= max_latency_ms]
        if not eligible:
            eligible = scores  # fallback: ignore SLA if none qualify
        best = eligible[0]
        return {
            "decision":      "ROUTE_NOW",
            "job_type":      "realtime",
            "route_to":      best["name"],
            "aws_region":    best["aws"],
            "score":         best["score"],
            "latency_ms":    best["latency"],
            "sla_met":       best["latency"] <= max_latency_ms,
            "reason":        f"Greenest region within {max_latency_ms}ms SLA",
            "timestamp":     datetime.now().isoformat()
        }
    else:
        best = scores[0]
        if best["carbon"] <= CARBON_THRESHOLD:
            return {
                "decision":   "ROUTE_NOW",
                "job_type":   "batch",
                "route_to":   best["name"],
                "carbon":     best["carbon"],
                "reason":     f"Carbon already low ({best['carbon']} ≤ {CARBON_THRESHOLD} gCO2/kWh)",
                "timestamp":  datetime.now().isoformat()
            }
        else:
            return {
                "decision":   "DEFERRED",
                "job_type":   "batch",
                "reason":     f"Carbon too high ({best['carbon']} > {CARBON_THRESHOLD} gCO2/kWh)",
                "current_best": best["name"],
                "carbon_now": best["carbon"],
                "threshold":  CARBON_THRESHOLD,
                "retry_in":   "15 minutes",
                "timestamp":  datetime.now().isoformat()
            }

@app.get("/savings")
def savings_summary():
    """Returns cumulative CO2 savings since system started"""
    try:
        with open("routing_log.json") as f:
            log = json.load(f)
        total_saved  = round(sum(e["co2_saved_g"] for e in log), 6)
        total_runs   = len(log)
        region_counts= {}
        for e in log:
            region_counts[e["routed_to"]] = region_counts.get(e["routed_to"],0)+1
        most_used = max(region_counts, key=region_counts.get)
        return {
            "total_routing_decisions": total_runs,
            "total_co2_saved_grams":   total_saved,
            "co2_saved_per_1000_reqs": round(total_saved * 1000, 2),
            "most_used_region":        most_used,
            "region_distribution":     region_counts,
            "vs_strategy":             "round-robin baseline"
        }
    except:
        return {"error": "No routing history yet. Run /best-region first."}

@app.get("/predict")
def predict():
    """Returns ML prediction for best region in next hour"""
    try:
        with open("ml_prediction.json") as f:
            return json.load(f)
    except:
        return {
            "error": "No ML prediction available yet.",
            "fix":   "Run ml_predictor.py after collecting 10+ routing decisions"
        }

# ── DASHBOARD ────────────────────────────────────────────────
@app.get("/dashboard", response_class=HTMLResponse)
def dashboard():
    scores    = get_all_scores()
    best      = scores[0]
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # CO2 savings
    try:
        with open("routing_log.json") as f:
            log = json.load(f)
        total_saved = round(sum(e["co2_saved_g"] for e in log), 4)
        total_runs  = len(log)
    except:
        total_saved, total_runs = 0, 0

    # ML prediction
    try:
        with open("ml_prediction.json") as f:
            ml = json.load(f)
        ml_best    = ml["best_region"]
        ml_time    = ml["predicted_for"]
        ml_score   = ml["best_score"]
        ml_html    = f"<b style='color:#a29bfe'>{ml_best}</b> (score {ml_score}) @ {ml_time}"
    except:
        ml_html = "<span style='color:#555'>Run ml_predictor.py to enable</span>"

    # Region cards
    cards = ""
    for i, r in enumerate(scores):
        is_best = r["name"] == best["name"]
        border  = "#2ecc71" if is_best else "#2a2a3e"
        bg      = "#0a2a1a" if is_best else "#13132a"
        badge   = "👑 BEST" if is_best else f"#{i+1}"
        bc      = "#2ecc71" if is_best else "#444"
        bt      = "#000"    if is_best else "#fff"

        def bar(val, color):
            w = int(val * 140)
            return (f"<div style='background:#111;border-radius:3px;height:8px;width:140px'>"
                    f"<div style='background:{color};width:{w}px;height:8px;border-radius:3px'>"
                    f"</div></div>")

        cards += f"""
        <div style="background:{bg};border:2px solid {border};border-radius:14px;
                    padding:20px;flex:1;min-width:200px">
          <div style="display:flex;justify-content:space-between;margin-bottom:10px">
            <span style="font-size:20px;font-weight:bold">{r['flag']} {r['name']}</span>
            <span style="background:{bc};color:{bt};padding:3px 10px;
                         border-radius:10px;font-size:11px">{badge}</span>
          </div>
          <div style="color:#666;font-size:11px;margin-bottom:14px">
            {r['location']} · {r['aws']}</div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px">
            <div style="background:#0a0a1a;border-radius:6px;padding:8px;text-align:center">
              <div style="color:#e74c3c;font-size:16px;font-weight:bold">{r['carbon']}</div>
              <div style="color:#555;font-size:9px">gCO2/kWh</div>
            </div>
            <div style="background:#0a0a1a;border-radius:6px;padding:8px;text-align:center">
              <div style="color:#3498db;font-size:16px;font-weight:bold">{r['pue']}</div>
              <div style="color:#555;font-size:9px">PUE</div>
            </div>
            <div style="background:#0a0a1a;border-radius:6px;padding:8px;text-align:center">
              <div style="color:#f39c12;font-size:16px;font-weight:bold">{r['latency']}ms</div>
              <div style="color:#555;font-size:9px">Latency</div>
            </div>
            <div style="background:#0a0a1a;border-radius:6px;padding:8px;text-align:center">
              <div style="color:#00b894;font-size:16px;font-weight:bold">{r['renewable']}%</div>
              <div style="color:#555;font-size:9px">Renewable</div>
            </div>
          </div>

          <div style="font-size:10px;color:#555;margin-bottom:3px">
            Carbon(35%) {bar(r['carbon_score'],'#e74c3c')}</div>
          <div style="font-size:10px;color:#555;margin-bottom:3px">
            Cooling(30%) {bar(r['cooling_score'],'#3498db')}</div>
          <div style="font-size:10px;color:#555;margin-bottom:3px">
            Latency(20%) {bar(r['latency_score'],'#f39c12')}</div>
          <div style="font-size:10px;color:#555;margin-bottom:10px">
            Renewable(15%) {bar(r['renewable_score'],'#00b894')}</div>

          <div style="text-align:center;background:#0a0a1a;border-radius:6px;padding:8px">
            <span style="color:#2ecc71;font-size:20px;font-weight:bold">{r['score']}</span>
            <div style="color:#555;font-size:10px">Eco-Score</div>
          </div>
        </div>"""

    return f"""<!DOCTYPE html>
    <html>
    <head>
      <title>Eco-Router Dashboard</title>
      <meta http-equiv="refresh" content="30">
      <style>
        *    {{ box-sizing:border-box;margin:0;padding:0 }}
        body {{ background:#0a0a1a;font-family:Arial,sans-serif;color:white }}
        .header {{ background:linear-gradient(135deg,#0a2a1a,#0a0a2a);
                   padding:24px 36px;border-bottom:2px solid #2ecc71 }}
        .header h1 {{ font-size:22px;color:#2ecc71 }}
        .header p  {{ color:#555;font-size:12px;margin-top:5px }}
        .banner {{ margin:20px 36px;background:#0a2a1a;border:1px solid #2ecc71;
                   border-radius:12px;padding:18px 24px }}
        .badge  {{ background:#2ecc71;color:#000;padding:8px 20px;
                   border-radius:20px;font-size:18px;font-weight:bold }}
        .grid4  {{ display:grid;grid-template-columns:repeat(4,1fr);
                   gap:12px;margin:20px 36px }}
        .stat   {{ background:#13132a;border:1px solid #2a2a3e;
                   border-radius:10px;padding:14px;text-align:center }}
        .sv     {{ font-size:20px;font-weight:bold;color:#2ecc71 }}
        .sl     {{ color:#555;font-size:10px;margin-top:3px }}
        .cards  {{ display:flex;gap:14px;margin:0 36px 36px;flex-wrap:wrap }}
        .info   {{ margin:0 36px 20px;background:#13132a;border:1px solid #2a2a3e;
                   border-radius:10px;padding:14px 20px;font-size:12px;color:#888 }}
        .info span {{ color:#2ecc71;font-weight:bold }}
        .footer {{ text-align:center;color:#333;font-size:11px;
                   padding:16px;border-top:1px solid #1a1a2e }}
      </style>
    </head>
    <body>
      <div class="header">
        <h1>🌱 Multi-Region Eco-Routing Load Balancer</h1>
        <p>4-Factor Model: Carbon(35%) + Cooling(30%) + Latency(20%) + Renewable(15%)
           &nbsp;·&nbsp; {timestamp} &nbsp;·&nbsp; Auto-refresh 30s</p>
      </div>

      <div class="banner">
        <div style="color:#888;font-size:11px;margin-bottom:8px">
          Routing all traffic to →</div>
        <span class="badge">{best['flag']} {best['name']} — {best['location']}</span>
        <span style="color:#aaa;font-size:13px;margin-left:16px">
          {best['aws']} &nbsp;|&nbsp; Score: <b style="color:#2ecc71">{best['score']}</b>
        </span>
      </div>

      <div class="grid4">
        <div class="stat"><div class="sv">{best['carbon']}</div>
          <div class="sl">gCO2/kWh Carbon</div></div>
        <div class="stat"><div class="sv">{best['pue']}</div>
          <div class="sl">PUE Cooling</div></div>
        <div class="stat"><div class="sv">{best['latency']}ms</div>
          <div class="sl">RTT Latency</div></div>
        <div class="stat"><div class="sv">{best['renewable']}%</div>
          <div class="sl">Renewable Energy</div></div>
        <div class="stat"><div class="sv">{best['score']}</div>
          <div class="sl">Eco-Score</div></div>
        <div class="stat"><div class="sv">{total_runs}</div>
          <div class="sl">Routing Decisions</div></div>
        <div class="stat"><div class="sv">{total_saved}g</div>
          <div class="sl">CO₂ Saved</div></div>
        <div class="stat"><div class="sv">4</div>
          <div class="sl">Regions Monitored</div></div>
      </div>

      <div class="info">
        🤖 <span>ML Prediction (next hour):</span> &nbsp; {ml_html}
        &nbsp;&nbsp;|&nbsp;&nbsp;
        🔗 <span>API:</span>
        <a href="/best-region" style="color:#3498db">/best-region</a> &nbsp;
        <a href="/scores" style="color:#3498db">/scores</a> &nbsp;
        <a href="/savings" style="color:#3498db">/savings</a> &nbsp;
        <a href="/predict" style="color:#3498db">/predict</a> &nbsp;
        <a href="/docs" style="color:#3498db">/docs</a>
      </div>

      <div class="cards">{cards}</div>

      <div class="footer">
        🌱 Multi-Region Eco-Routing Load Balancer &nbsp;|&nbsp;
        Novel 4-Factor Eco-Score Model &nbsp;|&nbsp;
        Amrita Vishwa Vidyapeetham &nbsp;|&nbsp; Cloud Computing 2026
      </div>
    </body>
    </html>"""