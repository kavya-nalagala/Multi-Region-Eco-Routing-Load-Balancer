"""
ML Score Predictor — Novel Feature
===================================
Trains a Random Forest model on historical routing_log.json data.
Predicts which region will have the best eco-score 1 hour ahead.

Algorithm: Random Forest Regressor
Features : hour_of_day, day_of_week, current_carbon, current_renewable
Target   : eco_score per region (one model per region)

Why Random Forest?
- Handles non-linear patterns in energy grid data
- Works well with small datasets (50+ records)
- No scaling needed
- Interpretable feature importance
"""

import json
import os
from datetime import datetime, timedelta

# Install if needed: pip install scikit-learn numpy
try:
    import numpy as np
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import mean_absolute_error
    ML_AVAILABLE = True
except ImportError:
    ML_AVAILABLE = False
    print("  Install scikit-learn: pip install scikit-learn numpy")

# ─── LOAD TRAINING DATA ──────────────────────────────────────
def load_training_data():
    """
    Loads historical scores from routing_log.json.
    Each entry becomes one training sample.
    Minimum 10 records needed to train.
    """
    try:
        with open("routing_log.json", "r") as f:
            log = json.load(f)
        if len(log) < 10:
            return None, f"Need at least 10 records to train. Have {len(log)}."
        return log, None
    except FileNotFoundError:
        return None, "routing_log.json not found. Run scorer.py a few times first."
    except Exception as e:
        return None, str(e)

# ─── PREPARE FEATURES ────────────────────────────────────────
def prepare_features(log):
    """
    Features used for prediction:
      - hour_of_day   : carbon intensity follows daily patterns
      - day_of_week   : weekday vs weekend grid usage differs
      - carbon         : current carbon reading
      - renewable      : current renewable percentage

    Target: eco_score for each region
    """
    regions = ["Norway", "Oregon", "Singapore", "Virginia"]
    X, Y = {r: [] for r in regions}, {r: [] for r in regions}

    for entry in log:
        hour    = entry.get("hour", 12)
        dow     = entry.get("day_of_week", 0)
        carbon  = entry.get("carbon", 200)
        renew   = entry.get("renewable", 50)
        scores  = entry.get("all_scores", {})

        features = [hour, dow, carbon, renew,
                    # Time-of-day cyclical encoding (helps ML understand 23→0 wrap)
                    round(__import__('math').sin(2 * 3.14159 * hour / 24), 4),
                    round(__import__('math').cos(2 * 3.14159 * hour / 24), 4)]

        for region in regions:
            if region in scores:
                X[region].append(features)
                Y[region].append(scores[region])

    return X, Y, regions

# ─── TRAIN MODELS ────────────────────────────────────────────
def train_models(X, Y, regions):
    """
    Trains one Random Forest model per region.
    Returns trained models and accuracy metrics.
    """
    models  = {}
    metrics = {}

    for region in regions:
        if len(X[region]) < 10:
            continue

        X_arr = np.array(X[region])
        Y_arr = np.array(Y[region])

        # Split 80% train, 20% test
        X_train, X_test, y_train, y_test = train_test_split(
            X_arr, Y_arr, test_size=0.2, random_state=42)

        # Train Random Forest
        model = RandomForestRegressor(
            n_estimators=100,    # 100 decision trees
            max_depth=5,         # prevent overfitting
            random_state=42
        )
        model.fit(X_train, y_train)

        # Evaluate
        y_pred = model.predict(X_test)
        mae    = mean_absolute_error(y_test, y_pred)

        models[region]  = model
        metrics[region] = {
            "mae":        round(mae, 4),
            "samples":    len(X[region]),
            "accuracy":   f"{round((1 - mae) * 100, 1)}%"
        }

    return models, metrics

# ─── PREDICT 1 HOUR AHEAD ────────────────────────────────────
def predict_next_hour(models, metrics):
    """
    Predicts eco-scores 1 hour from now.
    Uses next hour's time features + current carbon/renewable as input.
    Returns predicted best region.
    """
    import math

    next_hour = (datetime.now() + timedelta(hours=1))
    hour      = next_hour.hour
    dow       = next_hour.weekday()

    # Use current carbon/renewable as proxy for next hour
    # In production this would use Electricity Maps forecast API
    try:
        with open("routing_log.json") as f:
            log = json.load(f)
        latest = log[-1]
        carbon  = latest.get("carbon", 200)
        renew   = latest.get("renewable", 50)
    except:
        carbon, renew = 200, 50

    features = np.array([[
        hour, dow, carbon, renew,
        round(math.sin(2 * 3.14159 * hour / 24), 4),
        round(math.cos(2 * 3.14159 * hour / 24), 4)
    ]])

    predictions = {}
    for region, model in models.items():
        pred = model.predict(features)[0]
        predictions[region] = round(pred, 3)

    best_predicted = max(predictions, key=predictions.get)

    return {
        "predicted_for":    next_hour.strftime("%Y-%m-%d %H:00"),
        "predictions":      predictions,
        "best_region":      best_predicted,
        "best_score":       predictions[best_predicted],
        "model_metrics":    metrics,
        "features_used":    ["hour_of_day","day_of_week",
                             "carbon","renewable","sin_hour","cos_hour"]
    }

# ─── MAIN ────────────────────────────────────────────────────
def run_predictor():
    print("\n" + "="*60)
    print("  ML SCORE PREDICTOR — Random Forest")
    print(f"  Predicting best region for next hour")
    print("="*60)

    if not ML_AVAILABLE:
        print("  ❌ scikit-learn not installed.")
        print("  Run: pip install scikit-learn numpy")
        return

    log, error = load_training_data()
    if error:
        print(f"  ❌ {error}")
        return

    print(f"  ✅ Loaded {len(log)} training records")
    print("  Training Random Forest models...")

    X, Y, regions = prepare_features(log)
    models, metrics = train_models(X, Y, regions)

    if not models:
        print("  ❌ Not enough data per region. Run scorer.py more times.")
        return

    print("\n  Model Accuracy per Region:")
    for region, m in metrics.items():
        print(f"    {region:12} — MAE: {m['mae']}  "
              f"Samples: {m['samples']}  Accuracy: {m['accuracy']}")

    result = predict_next_hour(models, metrics)

    print(f"\n  📅 Prediction for: {result['predicted_for']}")
    print(f"\n  Predicted Scores:")
    for region, score in sorted(result["predictions"].items(),
                                key=lambda x: x[1], reverse=True):
        marker = " ← PREDICTED BEST" if region == result["best_region"] else ""
        print(f"    {region:12} : {score}{marker}")

    print(f"\n  ✅ PREDICTED BEST REGION → {result['best_region']}")
    print(f"     Predicted Score: {result['best_score']}")
    print("="*60)

    # Save prediction
    with open("ml_prediction.json", "w") as f:
        json.dump(result, f, indent=2)
    print(f"  Prediction saved to ml_prediction.json\n")

    return result

if __name__ == "__main__":
    run_predictor()