import requests
import json
import subprocess
import platform
import random
import math
from datetime import datetime
from tabulate import tabulate

# Remove this:
API_KEY = "rTjS9rZcvBMCeurVY8FR"

# Add this:
import os
from dotenv import load_dotenv
load_dotenv()
API_KEY = os.getenv("ELECTRICITY_MAPS_KEY")

# ─── 8 REGIONS — chosen for genuine competition ──────────────
# Key insight: regions compete on DIFFERENT strengths
#   Norway    → best carbon + best PUE  (green champion)
#   Finland   → very clean grid, cold climate
#   Canada    → hydro power, close to US users
#   Oregon    → wind power, low latency to US
#   Mumbai    → close to India (you!) but dirty grid
#   São Paulo → improving renewables, South America
#   Sydney    → coal-heavy but improving
#   Tokyo     → nuclear + gas mix, low latency to Asia
#
# PUE Sources: AWS Sustainability Report 2024, GCP Sustainability Report 2024
# Zone codes: Electricity Maps API v4

REGIONS = {
    "Norway": {
        "zone":     "NO",
        "pue":      1.04,    # AWS Europe best — AWS Report 2024
        "location": "Oslo, Norway",
        "aws":      "eu-north-1",
        "host":     "ec2.eu-north-1.amazonaws.com",
        "flag":     "🇳🇴",
        "strength": "Cleanest grid + best cooling"
    },
    "Finland": {
        "zone":     "FI",
        "pue":      1.07,    # GCP Finland — cold climate, nuclear+hydro
        "location": "Helsinki, Finland",
        "aws":      "eu-north-1",   # shares Nordic AWS region
        "host":     "ec2.eu-north-1.amazonaws.com",
        "flag":     "🇫🇮",
        "strength": "Nuclear + hydro, very cold climate"
    },
    "Canada": {
        "zone":     "CA-QC",        # Quebec — almost 100% hydro
        "pue":      1.10,    # AWS Canada estimated — cold climate
        "location": "Montreal, Canada",
        "aws":      "ca-central-1",
        "host":     "ec2.ca-central-1.amazonaws.com",
        "flag":     "🇨🇦",
        "strength": "Quebec hydro — very clean grid"
    },
    "Oregon": {
        "zone":     "US-NW-PACW",
        "pue":      1.10,    # GCP Oregon 1.07, AWS Americas best 1.05
        "location": "Portland, USA",
        "aws":      "us-west-2",
        "host":     "ec2.us-west-2.amazonaws.com",
        "flag":     "🇺🇸",
        "strength": "Wind power, low latency to US"
    },
    "Mumbai": {
        "zone":     "IN-WE",        # India West
        "pue":      1.40,    # Hot climate, estimated from AWS AP avg
        "location": "Mumbai, India",
        "aws":      "ap-south-1",
        "host":     "ec2.ap-south-1.amazonaws.com",
        "flag":     "🇮🇳",
        "strength": "Lowest latency for Indian users"
    },
    "São Paulo": {
        "zone":     "BR-CS",        # Brazil Central-South
        "pue":      1.35,    # Tropical climate, estimated
        "location": "São Paulo, Brazil",
        "aws":      "sa-east-1",
        "host":     "ec2.sa-east-1.amazonaws.com",
        "flag":     "🇧🇷",
        "strength": "Growing renewables, Latin America"
    },
    "Sydney": {
        "zone":     "AU-NSW",       # New South Wales
        "pue":      1.25,    # Moderate climate, AWS AP 1.07 best
        "location": "Sydney, Australia",
        "aws":      "ap-southeast-2",
        "host":     "ec2.ap-southeast-2.amazonaws.com",
        "flag":     "🇦🇺",
        "strength": "Pacific region coverage"
    },
    "Tokyo": {
        "zone":     "JP-TK",        # Tokyo area
        "pue":      1.20,    # GCP Tokyo, dense urban DC
        "location": "Tokyo, Japan",
        "aws":      "ap-northeast-1",
        "host":     "ec2.ap-northeast-1.amazonaws.com",
        "flag":     "🇯🇵",
        "strength": "Nuclear + low latency to East Asia"
    },
}

# ─── FALLBACK CARBON VALUES (gCO2/kWh) ──────────────────────
# Based on known grid characteristics per region
CARBON_FALLBACK = {
    "Norway":    28,    # hydro dominant
    "Finland":   80,    # nuclear + hydro mix
    "Canada":    25,    # Quebec = almost 100% hydro
    "Oregon":    180,   # wind + gas mix
    "Mumbai":    620,   # coal heavy grid
    "São Paulo": 140,   # sugarcane + hydro
    "Sydney":    480,   # coal dominant
    "Tokyo":     430,   # gas + nuclear mix
}

# ─── FALLBACK LATENCY (ms from Bengaluru, India) ────────────
# You are in Bengaluru — these are realistic RTTs
LATENCY_FALLBACK = {
    "Norway":    180,
    "Finland":   175,
    "Canada":    220,
    "Oregon":    210,
    "Mumbai":    30,    # very close to you!
    "São Paulo": 320,
    "Sydney":    140,
    "Tokyo":     110,
}

# ─── FALLBACK RENEWABLE % ───────────────────────────────────
RENEWABLE_FALLBACK = {
    "Norway":    95.0,
    "Finland":   55.0,
    "Canada":    98.0,   # Quebec hydro
    "Oregon":    65.0,
    "Mumbai":    18.0,
    "São Paulo": 75.0,   # sugarcane + hydro
    "Sydney":    28.0,
    "Tokyo":     22.0,
}

# ─── FETCH CARBON (live) ─────────────────────────────────────
def get_carbon(zone, region_name):
    try:
        url = f"https://api.electricitymaps.com/v4/carbon-intensity/latest?zone={zone}"
        r = requests.get(url, headers={"auth-token": API_KEY}, timeout=10)
        val = r.json().get("carbonIntensity")
        if val is not None:
            return val, "live"
    except:
        pass
    return CARBON_FALLBACK[region_name], "fallback"

# ─── FETCH RENEWABLE % (live) ────────────────────────────────
def get_renewable(zone, region_name):
    try:
        url = f"https://api.electricitymaps.com/v4/power-breakdown/latest?zone={zone}"
        r = requests.get(url, headers={"auth-token": API_KEY}, timeout=10)
        data = r.json()
        breakdown = data.get("powerConsumptionBreakdown", {})
        total = sum(breakdown.values()) or 1
        sources = ["hydro","wind","solar","nuclear","geothermal","biomass"]
        renew_mw = sum(breakdown.get(s, 0) for s in sources)
        return round((renew_mw / total) * 100, 1), "live"
    except:
        pass
    return RENEWABLE_FALLBACK.get(region_name, 30.0), "estimated"

# ─── MEASURE LATENCY (live ping) ─────────────────────────────
def measure_latency(host):
    try:
        param = "-n" if platform.system().lower() == "windows" else "-c"
        result = subprocess.run(["ping", param, "4", host],
                                capture_output=True, text=True, timeout=15)
        output = result.stdout
        if platform.system().lower() == "windows":
            for line in output.split("\n"):
                if "Average" in line:
                    ms = line.split("=")[-1].strip().replace("ms","").strip()
                    return int(ms), "measured"
        else:
            for line in output.split("\n"):
                if "rtt" in line:
                    return int(float(line.split("/")[4])), "measured"
    except:
        pass
    return None, None

def get_latency(region_name):
    host = REGIONS[region_name]["host"]
    lat, src = measure_latency(host)
    if lat is None:
        return LATENCY_FALLBACK[region_name], "estimated"
    return lat, src

# ─── 4-FACTOR ECO-SCORE FORMULA ──────────────────────────────
def calculate_score(carbon, pue, latency, renewable_pct):
    """
    Novel 4-Factor Eco-Score:
    Score = Carbon(35%) + Cooling(30%) + Latency(20%) + Renewable(15%)
    """
    c  = max(0, 1 - carbon       / 700)   # max carbon ~700 for coal regions
    p  = max(0, 1 - (pue - 1.0) / 0.8)   # max PUE penalty at 1.8
    l  = max(0, 1 - latency      / 400)   # max latency 400ms
    re = max(0, renewable_pct    / 100)

    total = (c*0.35 + p*0.30 + l*0.20 + re*0.15)
    return round(total,3), round(c,3), round(p,3), round(l,3), round(re,3)

# ─── CO2 SAVINGS TRACKER ─────────────────────────────────────
def log_and_calculate_savings(winner, all_results):
    avg_carbon  = sum(r["carbon"] for r in all_results) / len(all_results)
    best_carbon = winner["carbon"]
    co2_saved   = round((avg_carbon - best_carbon) * 0.001, 6)

    entry = {
        "timestamp":   datetime.now().isoformat(),
        "hour":        datetime.now().hour,
        "day_of_week": datetime.now().weekday(),
        "routed_to":   winner["name"],
        "carbon":      winner["carbon"],
        "pue":         winner["pue"],
        "latency":     winner["latency"],
        "renewable":   winner["renewable"],
        "score":       winner["score"],
        "avg_carbon":  round(avg_carbon, 2),
        "co2_saved_g": co2_saved,
        "all_scores":  {r["name"]: r["score"] for r in all_results}
    }

    log = []
    try:
        with open("routing_log.json", "r") as f:
            log = json.load(f)
    except:
        pass
    log.append(entry)
    with open("routing_log.json", "w") as f:
        json.dump(log, f, indent=2)

    return co2_saved, round(avg_carbon, 2)

# ─── GET ALL SCORES ──────────────────────────────────────────
def get_all_scores():
    results = []
    for name, info in REGIONS.items():
        carbon,    c_src  = get_carbon(info["zone"], name)
        renewable, re_src = get_renewable(info["zone"], name)
        latency,   l_src  = get_latency(name)
        score, c_sc, p_sc, l_sc, re_sc = calculate_score(
            carbon, info["pue"], latency, renewable)
        results.append({
            "name":           name,
            "flag":           info["flag"],
            "location":       info["location"],
            "aws":            info["aws"],
            "strength":       info["strength"],
            "carbon":         carbon,
            "carbon_src":     c_src,
            "pue":            info["pue"],
            "latency":        latency,
            "latency_src":    l_src,
            "renewable":      renewable,
            "renewable_src":  re_src,
            "score":          score,
            "carbon_score":   c_sc,
            "cooling_score":  p_sc,
            "latency_score":  l_sc,
            "renewable_score":re_sc,
        })
    return sorted(results, key=lambda x: x["score"], reverse=True)

# ─── MAIN ────────────────────────────────────────────────────
def run_scorer():
    print("\n" + "="*75)
    print("   ECO-ROUTING LOAD BALANCER — 8-Region Live Scores")
    print(f"   {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("   4-Factor: Carbon(35%) + Cooling(30%) + Latency(20%) + Renewable(15%)")
    print("="*75)

    results = get_all_scores()

    table = [[f"#{i+1}", r["flag"]+r["name"],
              f"{r['carbon']}({r['carbon_src'][0]})",
              r["pue"],
              f"{r['latency']}ms({r['latency_src'][0]})",
              f"{r['renewable']}%",
              r["score"]]
             for i, r in enumerate(results)]

    print(tabulate(table,
        headers=["Rank","Region","Carbon gCO2","PUE","Latency","Renew%","Score"],
        tablefmt="rounded_outline"))

    # Breakdown
    print("\n  Score Breakdown:")
    bd = [[r["name"],
           f"{r['carbon_score']}×.35",
           f"{r['cooling_score']}×.30",
           f"{r['latency_score']}×.20",
           f"{r['renewable_score']}×.15",
           f"={r['score']}",
           r["strength"]]
          for r in results]
    print(tabulate(bd,
        headers=["Region","Carbon","Cooling","Latency","Renewable","Total","Strength"],
        tablefmt="simple"))

    winner = results[0]
    co2_saved, avg_carbon = log_and_calculate_savings(winner, results)

    print(f"\n{'='*75}")
    print(f"  ✅ ROUTE TO → {winner['flag']} {winner['name']} ({winner['location']})")
    print(f"  Strength    : {winner['strength']}")
    print(f"  AWS Region  : {winner['aws']}")
    print(f"  Carbon      : {winner['carbon']} gCO2/kWh ({winner['carbon_src']})")
    print(f"  PUE         : {winner['pue']}")
    print(f"  Latency     : {winner['latency']} ms ({winner['latency_src']})")
    print(f"  Renewable   : {winner['renewable']}%")
    print(f"  Eco-Score   : {winner['score']}")
    print(f"  💚 CO₂ Saved: {co2_saved}g vs round-robin (avg {avg_carbon} gCO2)")
    print(f"{'='*75}\n")

    try:
        with open("routing_log.json") as f:
            log = json.load(f)
        total = round(sum(e["co2_saved_g"] for e in log), 4)
        counts = {}
        for e in log:
            counts[e["routed_to"]] = counts.get(e["routed_to"], 0) + 1
        print(f"  📊 Total CO₂ saved: {total}g over {len(log)} decisions")
        print(f"  📊 Region wins: {counts}")
    except:
        pass

if __name__ == "__main__":
    run_scorer()